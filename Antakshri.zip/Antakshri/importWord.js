const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/wordAntakshari', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log("Connected to MongoDB"))
.catch(err => console.error("MongoDB Connection Error:", err));

// Define Schema and Model
const wordSchema = new mongoose.Schema({ word: { type: String, unique: true } });
const Word = mongoose.model('Word', wordSchema);

// Import Words Function
async function importWords() {
    const filePath = path.join(__dirname, 'words_alpha.txt');
    const words = fs.readFileSync(filePath, 'utf8').split('\n').map(w => w.trim().toLowerCase());
    
    // Corrected console.log statement
    console.log(`Total words found: ${words.length}`);

    for (const word of words) {
        if (word.length >= 3) {
            try {
                await Word.updateOne({ word }, { $setOnInsert: { word } }, { upsert: true });
            } catch (error) {
                console.error(`Error inserting word: ${word}`);
            }
        }
    }
    console.log("Word import completed!");
    mongoose.connection.close();
}

// Run the import function
importWords();