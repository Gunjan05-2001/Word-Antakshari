document.getElementById("startBtn").addEventListener("click", startGame);
document.getElementById("submitBtn").addEventListener("click", submitWord);

let lastLetter = "";
let score = 0;

async function startGame() {
    try {
        const res = await fetch("/start");
        const data = await res.json();

        if (data.word) {
            lastLetter = data.lastLetter.toLowerCase();
            score = 0;

            document.getElementById("currentWord").innerText = data.word;
            document.getElementById("lastLetter").innerText = lastLetter;
            document.getElementById("score").innerText = score;
            document.getElementById("submitBtn").disabled = false;

            showMessage("Game Started!");
        } else {
            showMessage("Error: No word received!");
        }
    } catch (error) {
        showMessage("Failed to start game.");
    }
}

async function submitWord() {
    const wordInput = document.getElementById("wordInput").value.trim().toLowerCase();

    console.log(`📩 Entered word: ${wordInput}, Expected last letter: '${lastLetter}'`);

    if (!wordInput) return showMessage("Please enter a word!");
    
    if (wordInput[0] !== lastLetter) {
        console.log(`❌ Frontend check failed: ${wordInput} does not start with '${lastLetter}'`);
        return showMessage(`Word must start with '${lastLetter.toUpperCase()}'!`);
    }

    try {
        const res = await fetch("/submit", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ word: wordInput }),
        });

        const data = await res.json();
        console.log(`📩 Server Response:`, data);

        if (!res.ok) return showMessage(data.message);

        lastLetter = data.lastLetter.toLowerCase();
        document.getElementById("lastLetter").innerText = lastLetter;

        if (data.newWord) {
            document.getElementById("currentWord").innerText = data.newWord;
        }

        if (data.players) {
            score = data.players[0]?.score || 0;
            document.getElementById("score").innerText = score;
        }

        document.getElementById("wordInput").value = "";
        showMessage(data.message);
    } catch (error) {
        showMessage("Failed to submit word.");
    }
}

function showMessage(msg) {
    document.getElementById("message").innerText = msg;
}