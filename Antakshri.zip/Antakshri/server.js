const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/wordAntakshari', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log("✅ Connected to MongoDB successfully!"))
.catch(err => console.error("❌ Error connecting to MongoDB:", err));

// Models
const wordSchema = new mongoose.Schema({ word: { type: String, unique: true } });
const Word = mongoose.model('Word', wordSchema);

const playerSchema = new mongoose.Schema({ name: String, score: Number });
const Player = mongoose.model('Player', playerSchema);

// Game Variables
let lastLetter = '';
let usedWords = new Set();
let players = [];
let currentPlayerIndex = 0;

// Initialize Players
async function initializePlayers() {
    players = await Player.find();
    if (players.length === 0) {
        players = [{ name: 'Player 1', score: 0 }, { name: 'Player 2', score: 0 }];
        await Player.insertMany(players);
    }
}

// Start Game Route
app.get('/start', async (req, res) => {
    await initializePlayers();
    const randomWord = await Word.aggregate([{ $sample: { size: 1 } }]);
    if (randomWord.length) {
        lastLetter = randomWord[0].word.slice(-1).toLowerCase();
        usedWords.clear();
        await Player.updateMany({}, { score: 0 });

        return res.json({ 
            message: 'Game Started!', 
            word: randomWord[0].word, 
            lastLetter, 
            players 
        });
    }
    return res.status(500).json({ message: 'No words found in database.' });
});

// Submit Word Route
app.post('/submit', async (req, res) => {
    let { word } = req.body;
    word = word.toLowerCase().trim();

    console.log(`🔍 Received word: ${word}, Expected last letter: '${lastLetter}'`);

    if (!word) return res.status(400).json({ message: "Word cannot be empty!" });
    if (word[0] !== lastLetter) {
        console.log(`❌ Word rejected! ${word} does not start with ${lastLetter}`);
        return res.status(400).json({ message: `Invalid! Word must start with '${lastLetter.toUpperCase()}'` });
    }
    if (usedWords.has(word)) return updateScoreAndRespond(res, -5, "Word already used!");

    const wordExists = await Word.findOne({ word });
    if (!wordExists) return updateScoreAndRespond(res, -5, "Invalid word! Not found in dictionary.");

    // Set the current word to the submitted word
    const currentWord = word; // Update current word to the submitted word
    usedWords.add(currentWord);
    const score = currentWord.length * 2;

    // Set the last letter to the last letter of the submitted word
    lastLetter = currentWord.slice(-1).toLowerCase();
    console.log(`✅ New last letter set to: '${lastLetter}'`);

    // Return the submitted word as the current word
    return updateScoreAndRespond(res, score, "Word accepted!", true, currentWord);
});

// Update Score and Respond
async function updateScoreAndRespond(res, scoreChange, message, isAccepted = false, newWord = null) {
    players[currentPlayerIndex].score += scoreChange;
    await Player.updateOne({ name: players[currentPlayerIndex].name }, { $inc: { score: scoreChange } });
    if (isAccepted) currentPlayerIndex = (currentPlayerIndex + 1) % players.length;
    
    return res.json({ message, lastLetter, players, newWord });
};

// Get Leaderboard
app.get('/leaderboard', async (req, res) => {
    const players = await Player.find().sort({ score: -1 });
    return res.json(players);
});

// Start the server
app.listen(PORT, () => {
    console.log(`🚀 Server is running on http://localhost:${PORT}`);
});